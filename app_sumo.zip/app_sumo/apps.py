from django.apps import AppConfig


class AppSumoConfig(AppConfig):
    name = 'app_sumo'
